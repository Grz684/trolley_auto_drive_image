#pragma once

#include "writer.h"
#include "olei/olei_parser.h"
#include "communication/transport.h"

template <typename T>
class OleiWriter : public Writer<T>
{
public:
  OleiWriter(std::unique_ptr<Transport>&& transport, std::shared_ptr<Parser<T>> parser, rclcpp::Logger logger)
    : transport_(std::move(transport)), parser_(parser), is_running_(false), logger_(logger)
  {
  }

  virtual bool start()
  {
    std::unique_lock<std::mutex> lck(mtx_);
    is_running_ = true;
    if (transport_)
    {
      if (transport_->is_connected())
        return true;

      return transport_->connect();
    }
    return false;
  }

  virtual bool stop()
  {
    std::unique_lock<std::mutex> lck(mtx_);
    is_running_ = false;
    if (transport_ && transport_->is_connected())
    {
      return transport_->disconnect();
    }
    return false;
  }

  virtual bool get(std::vector<std::unique_ptr<T>>& packets)
  {
    std::unique_lock<std::mutex> lck(mtx_);
    if (!is_running_)
    {
      return false;
    }
    boost::array<uint8_t, 4096> buf;
    size_t read = 0;
    size_t used = 0;
    if (transport_->read(buf, read))
    {
      persistent_buffer_.insert(persistent_buffer_.end(), buf.begin(), buf.begin() + read);
      parser_->parse(persistent_buffer_.data(), persistent_buffer_.size(), packets, used, logger_);
      if (used)
      {
        if (used == persistent_buffer_.size())
          persistent_buffer_.clear();
        else
          persistent_buffer_.erase(persistent_buffer_.begin(), persistent_buffer_.begin() + used);
      }
      return true;  
    }
    return true;
  }

private:
  std::unique_ptr<Transport> transport_;
  std::shared_ptr<Parser<T>> parser_;
  std::vector<uint8_t> persistent_buffer_;
  bool is_running_;
  std::mutex mtx_;
  rclcpp::Logger logger_;
};
