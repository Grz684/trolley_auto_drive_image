import os

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    config_name = 'vf_params.yaml'

    ld = LaunchDescription()
    config = os.path.join(
        get_package_share_directory('olei_driver'),
        'config',
        config_name
        )

    node = Node(
        package='olei_driver',
        name='ros_main',
        executable='ros_main',
        output='screen',
        parameters=[config]
    )

    ld.add_action(node)
    return ld
